
const express = require('express');
const mysql = require('mysql2');
const nodemailer = require('nodemailer');
const crypto = require('crypto');
const cors = require('cors');

/* ------------------ CONFIGURAR APLICACIÓN ------------------ */
const app = express();
app.use(cors());
app.use(express.json());

/* ------------------ CONFIGURAR BASE DE DATOS ------------------ */
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'boletin_guevara'
});
db.connect(err => {
  if (err) {
    console.error('DB connect error:', err);
    process.exit(1);
  }
  console.log('Conectado a DB boletin_guevara');
});


/* ------------------ RUTAS Y ENDPOINTS ------------------ */
/* ------------------ REGISTRO DE USUARIOS ------------------ */
app.post('/api/usuarios', async (req, res) => {
  const { nombre, apellido, password, dni, gmail, ciudad, rol, Año, division } = req.body;

  if (!nombre || !apellido || !password || !dni || !gmail || !ciudad || !rol) {
    return res.status(400).json({ error: 'Faltan datos obligatorios' });
  }

  const rolesValidos = ['alumno', 'alumnado'];
  if (!rolesValidos.includes(rol)) {
    return res.status(400).json({ error: 'Rol inválido' });
  }

  try {
    const [result] = await db.query(
      'INSERT INTO usuarios (Nombre, Apellido, Contraseña, dni, gmail, ciudad, rol, estado) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [nombre, apellido, password, dni, gmail, ciudad, rol, 'pendiente']
    );

    const userId = result.insertId;

    if (rol === 'alumno') {
      await db.query('INSERT INTO alumnos (Año, Division, id_usuarios) VALUES (?, ?, ?)', [
        Año,
        division,
        userId
      ]);
      return res.json({ message: 'Alumno registrado correctamente' });
    }

    res.json({ message: 'Usuario registrado correctamente' });
  } catch (err) {
    console.error('Error al registrar usuario:', err);
    res.status(500).json({ error: 'Error al guardar usuario' });
  }
});

// Autocompletado alumnos (nombre completo + año/división si tienes esos campos)
app.get('/api/alumnos', (req, res) => {
  const search = req.query.q;
  const sql = `
    SELECT a.id_alumnos, CONCAT(u.Nombre, ' ', u.Apellido) as nombre_completo
    FROM alumnos a
    JOIN usuarios u ON a.id_usuarios = u.id_usuarios
    WHERE CONCAT(u.Nombre, ' ', u.Apellido) LIKE ?
    LIMIT 10
  `;
  db.query(sql, [`%${search}%`], (err, results) => {
    if (err) return res.status(500).json({ error: 'Error en la base de datos' });
    res.json(results);
  });
});

// Cargar nota
app.post('/api/cargar-nota', (req, res) => {
  const { idAlumno, materia, tipoNota, notaValor, cursoDivision } = req.body;

  if (!idAlumno || !materia || !tipoNota || !notaValor || !cursoDivision) {
    return res.status(400).json({ error: "Datos incompletos" });
  }

  const sqlMateria = `
    SELECT id_materias 
    FROM materias 
    WHERE LOWER(TRIM(NombreMateria)) = LOWER(TRIM(?))
    LIMIT 1
  `;
  db.query(sqlMateria, [materia], (err, results) => {
    if (err) {
      console.error('Error en la consulta de materia:', err);
      return res.status(500).json({ error: 'Error en la base de datos' });
    }
    if (results.length === 0) {
      return res.status(404).json({ error: 'Materia no encontrada' });
    }
    const idMateria = results[0].id_materias;
    const sqlInsert = `
      INSERT INTO notas (nota, tipodenota, id_alumnos, id_materias, curso_division)
      VALUES (?, ?, ?, ?, ?)
    `;
    db.query(sqlInsert, [notaValor, tipoNota, idAlumno, idMateria, cursoDivision], (err2) => {
      if (err2) {
        console.error('Error al insertar la nota:', err2);
        return res.status(500).json({ error: 'Error al insertar la nota' });
      }
      res.json({ mensaje: 'Nota cargada exitosamente' });
    });
  });
});
/* ------------------ LOGIN ------------------ */
app.post('/login', async (req, res) => {
  const { gmail, password } = req.body;

  if (!gmail || !password)
    return res.status(400).json({ error: 'Faltan datos' });

  try {
    const [results] = await db.query(
      `SELECT u.id_usuarios, u.Nombre, u.Apellido, u.rol, u.estado, a.id_alumnos
       FROM usuarios u
       LEFT JOIN alumnos a ON u.id_usuarios = a.id_usuarios
       WHERE u.gmail = ? AND u.Contraseña = ? LIMIT 1`,
      [gmail, password]
    );

    if (results.length === 0)
      return res.status(401).json({ error: 'Usuario o contraseña incorrectos' });

    const user = results[0];
    if (user.estado !== 'aceptado')
      return res.status(403).json({ error: 'Usuario no aceptado por el administrador' });

    res.json({
      id: user.id_usuarios,
      nombre: user.Nombre,
      apellido: user.Apellido,
      rol: user.rol,
      id_alumnos: user.id_alumnos || null
    });
  } catch (err) {
    console.error('Error en login:', err);
    res.status(500).json({ error: 'Error en el servidor' });
  }
});
/* ------------------ CONSULTAS Y RECUPERAR CONTRASEÑA ------------------ */

app.get('/api/consultas', (req, res) => {
  const sql = `
    SELECT c.id_consultas, u.Nombre, u.Apellido, c.mensaje, c.estado, c.respuesta
    FROM consultas c
    JOIN usuarios u ON c.id_usuarios = u.id_usuarios
    WHERE c.estado = "Pendiente"
    ORDER BY c.id_consultas DESC
  `;
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error al obtener consultas:', err);
      return res.status(500).json({ error: 'Error al obtener consultas' });
    }
    res.json(results);
  });
});

app.get('/api/consultas/usuario/:id_usuarios', (req, res) => {
  const { id_usuarios } = req.params;
  const sql = `
    SELECT c.id_consultas, c.mensaje, c.estado, c.respuesta
    FROM consultas c
    WHERE c.id_usuarios = ?
    ORDER BY c.id_consultas DESC
  `;
  db.query(sql, [id_usuarios], (err, results) => {
    if (err) {
      console.error('Error al obtener consultas del usuario:', err);
      return res.status(500).json({ error: 'Error al obtener consultas del usuario' });
    }
    res.json(results);
  });
});

app.post('/api/consultas/responder', (req, res) => {
  const { id_consulta, respuesta } = req.body;
  if (!id_consulta || !respuesta) return res.status(400).json({ error: 'Faltan datos de la respuesta' });
  const sql = 'UPDATE consultas SET estado = "Respondida", respuesta = ? WHERE id_consultas = ?';
  db.query(sql, [respuesta, id_consulta], (err) => {
    if (err) {
      console.error('Error al actualizar consulta:', err);
      return res.status(500).json({ error: 'Error al responder consulta' });
    }
    res.json({ message: 'Consulta respondida correctamente' });
  });
});

// Recuperar contraseña (tu implementación)
app.post('/api/recuperar', (req, res) => {
  const { gmail } = req.body;
  if (!gmail) return res.status(400).json({ error: 'Correo requerido' });
  const sqlSelect = 'SELECT * FROM usuarios WHERE gmail = ?';
  db.query(sqlSelect, [gmail], (err, results) => {
    if (err) {
      console.error('[ERROR SELECT]', err);
      return res.status(500).json({ error: 'Error en el servidor' });
    }
    if (results.length === 0) return res.status(400).json({ error: 'Correo no registrado' });

    const token = crypto.randomBytes(32).toString('hex');
    const expires = Date.now() + 3600 * 1000;
    const sqlUpdate = 'UPDATE usuarios SET reset_token = ?, reset_expires = ? WHERE gmail = ?';
    db.query(sqlUpdate, [token, expires, gmail], (err2) => {
      if (err2) {
        console.error('[ERROR UPDATE]', err2);
        return res.status(500).json({ error: 'Error al guardar token' });
      }

      const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: 'recuperacioncolegio2025@gmail.com',
          pass: 'ymry axiz rwuc fvuj'
        }
      });

      const enlaceRecuperacion = `http://localhost:3000/Restablecer.html?token=${token}`;
      const mailOptions = {
        from: 'recuperacioncolegio2025@gmail.com',
        to: gmail,
        subject: 'Recuperar contraseña',
        html: `<p>Hola, solicitaste recuperar tu contraseña.</p>
               <p>Haz clic en el siguiente enlace para restablecerla:</p>
               <a href="${enlaceRecuperacion}">${enlaceRecuperacion}</a>
               <p>Este enlace expirará en 1 hora.</p>`
      };

      transporter.sendMail(mailOptions, (err3, info) => {
        if (err3) {
          console.error('[ERROR EMAIL]', err3);
          return res.status(500).json({ error: 'Error al enviar el correo', detalles: err3.message });
        }
        console.log('[INFO] Correo enviado:', info.response);
        res.json({ message: 'Se ha enviado el enlace de recuperación a tu correo' });
      });
    });
  });
});

/* ------------------ INICIAR SERVIDOR ------------------ */
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});